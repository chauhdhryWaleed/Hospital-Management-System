using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace WebApplication1.Pages
{
    public class appointmentlistModel : PageModel
    {
        public List<appointmentinfo> appointmentlist = new List<appointmentinfo>();
        public void OnGet()
        {

            try
            {
                String connectionString = "Data Source=DESKTOP-QN8GHH2\\SQLEXPRESS02;Initial Catalog=DBConnectDemo;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    String sql = "Select * from appointment ;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                appointmentinfo info = new appointmentinfo();

                                info.ID = "" + reader.GetInt32(0);
                                info.Pname = reader.GetString(1);
                                info.PAge = "" + reader.GetInt32(2);
                                info.DrName = reader.GetString(4);
                                info.department = reader.GetString(6);
                                info.DiseaseName = reader.GetString(7);
                                info.date = reader.GetDateTime(8).ToString("yyyy-MM-dd");
                                info.time = reader.GetTimeSpan(9).ToString();


                                appointmentlist.Add(info);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception :" + ex.ToString());
            }
        }
    }
    public class appointmentinfo
    {

        public String ID;
        public String Pname;
        public String PAge;
        public String DrName;
        public String department;
        public String DiseaseName;
        public String date;
        public String time;



    }
}

