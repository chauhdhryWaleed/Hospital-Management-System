using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace WebApplication1.Pages
{
    public class patientlistModel : PageModel
    {
        public List<patientInfo> patientlist = new List<patientInfo>();   
        public void OnGet()
        {
            
            try
            {
                String connectionString = "Data Source=DESKTOP-QN8GHH2\\SQLEXPRESS02;Initial Catalog=DBConnectDemo;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    String sql = "Select * from patients ;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        using (SqlDataReader reader=cmd.ExecuteReader())
                        {
                           while(reader.Read())
                            {
                                patientInfo info = new patientInfo();
                                info.Id = "" + reader.GetInt32(0);
                                info.Name = reader.GetString(1)+" "+reader.GetString(2);
                                info.Gender = reader.GetString(3);
                                info.address = reader.GetString(4);
                                info.Disease = reader.GetString(5);
                                info.age = "" + reader.GetInt32(6);
                                info.PhoneNumber = reader.GetString(7);

                                info.BloodGroup = reader.GetString(8);
                                info.BedNo = "" + reader.GetInt32(9);
                                info.Doctorname= reader.GetString(10);

                                patientlist.Add(info);
                            }
                           
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception :"+ ex.ToString());
            }
        }
    }
    public class patientInfo
    {
        public String Id;
        public String Name;
        public String address;
        public String Gender;
        public String BloodGroup;
        public String Doctorname;

        public String age;
        public String Disease;
       
        public String PhoneNumber;
        public String BedNo;

      
    }
}
