using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
namespace WebApplication1.Pages
{
    public class loginModel : PageModel
    {
        String ErrorMessage;
        String SuccessMessage;
        int count = 0;
     public   adminInfo info = new adminInfo();
        public void OnGet()
        {
        }

        public void OnPost()
        {
            info.userName = Request.Form["name"];
            info.password = Request.Form["password"];


            if (info.userName.Length == 0 || info.password.Length == 0)
            {
                ErrorMessage = "All fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=DESKTOP-QN8GHH2\\SQLEXPRESS02;Initial Catalog=DBConnectDemo;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    String sql = "Select count(*) from [admin] where username=@username and password=@password;  ";
                    using (SqlCommand cmd = new SqlCommand(sql,conn))
                    {
                        cmd.Parameters.AddWithValue("@username", info.userName);
                        cmd.Parameters.AddWithValue("@password", info.password);

                        count = (int)cmd.ExecuteScalar();
                       
                        if (count > 0)
                        {
                            ModelState.Clear();
                            Response.Redirect("/Dashboard");
                        }
                        else
                        {
                            Console.WriteLine("No admin");
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                return;
            }
        }
    }
    public class adminInfo
    {
        public String password;
        public String userName;
    }
}
