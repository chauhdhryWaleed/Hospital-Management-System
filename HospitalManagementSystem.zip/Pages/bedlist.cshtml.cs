using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace WebApplication1.Pages
{
    public class bedlistModel : PageModel
    {
        public List<bedinfo> bedlist = new List<bedinfo>();
        public void OnGet()
        {

            try
            {
                String connectionString = "Data Source=DESKTOP-QN8GHH2\\SQLEXPRESS02;Initial Catalog=DBConnectDemo;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    String sql = "Select * from bed ;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bedinfo info = new bedinfo();

                                info.Bno = ""+reader.GetInt32(0);
                                info.pid = "" + reader.GetInt32(1);
                                info.pname = reader.GetString(2);
                                info.wardno = "" + reader.GetInt32(3);
                                info.department = reader.GetString(4);
                                bedlist.Add(info);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception :" + ex.ToString());
            }
        }
    }
    public class bedinfo
    {

        public String Bno;
        public String pid;
        public String pname;
        public String gender;
        public String wardno;
        public String department;
    }
}
