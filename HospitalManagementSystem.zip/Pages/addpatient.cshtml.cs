using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Runtime.Versioning;

namespace WebApplication1.Pages
{
    public class addpatientModel : PageModel
    {
        public patientInfo 
            info = new patientInfo();
        public String ErrorMessage;
        public String succcessMessage;
        public void OnGet()
        {
        }

        public void OnPost()
        {
            info.Id = Request.Form["PID"];
            info.Name = Request.Form["fname"]+  Request.Form["lname"];
            info.address = Request.Form["bio"];
            
            info.BedNo = Request.Form["BID"];
            info.BloodGroup = Request.Form["Blood"];
            info.Disease = Request.Form["disease"];
            info.Doctorname = Request.Form["doctor"];
            info.age = Request.Form["age"];
            info.Gender = Request.Form["mygender"];
            info.PhoneNumber = Request.Form["phone"];

            if(info.Id.Length ==0 || info.Name.Length == 0 || info.PhoneNumber.Length == 0 || info.Gender.Length == 0 ||
                info.address.Length == 0 || info.age.Length==0 || info.BedNo.Length == 0 || info.BloodGroup.Length == 0 || info.Disease.Length == 0 || info.Doctorname.Length == 0)
            {
                ErrorMessage = "All fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=DESKTOP-QN8GHH2\\SQLEXPRESS02;Initial Catalog=DBConnectDemo;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    String sql = "Insert into patients values(@id,@fname,@lname,@gender,@address,@Disease,@age,@phone,@Blood,@bedNo,@Doctor);";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id",info.Id);
                        cmd.Parameters.AddWithValue("@fname",info.Name);
                        cmd.Parameters.AddWithValue("@lname",info.Name);
                        cmd.Parameters.AddWithValue("@gender",info.Gender);
                        cmd.Parameters.AddWithValue("@address",info.address);
                        cmd.Parameters.AddWithValue("@Disease",info.Disease);
                        cmd.Parameters.AddWithValue("@age", info.age);
                        cmd.Parameters.AddWithValue("@phone",info.PhoneNumber);
                        cmd.Parameters.AddWithValue("@Blood",info.BloodGroup);
                        cmd.Parameters.AddWithValue("@bedNo",info.BedNo);
                        cmd.Parameters.AddWithValue("@Doctor",info.Doctorname);

                        cmd.ExecuteNonQuery();
                    }
                }
            }

            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                return;
            }
            ModelState.Clear();
            succcessMessage = "New Patient added successfully";
            Response.Redirect("/patientlist");

        }
    }
}
