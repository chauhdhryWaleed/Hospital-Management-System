using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace WebApplication1.Pages
{
    public class doctorlistModel : PageModel
    {
        public List<doctorinfo> doctorlist = new List<doctorinfo>();
        public void OnGet()
        {

            try
            {
                String connectionString = "Data Source=DESKTOP-QN8GHH2\\SQLEXPRESS02;Initial Catalog=DBConnectDemo;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    String sql = "Select * from doctor ;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                doctorinfo info = new doctorinfo();

                                info.Name = reader.GetString(0);
                                info.expertise = reader.GetString(1);
                                info.qualification = reader.GetString(2);
                                info.gender = reader.GetString(3);
                                info.department = reader.GetString(4);
                                info.PhoneNumber = reader.GetString(5);



                                doctorlist.Add(info);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception :" + ex.ToString());
            }
        }
    }
    public class doctorinfo
    {

        public String Name;
        public String expertise;
        public String qualification;
        public String gender;
        public String department;
        public String PhoneNumber;



    }
}